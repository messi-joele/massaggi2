<?php

class CentroMassaggi {
    private $connection;

    public function __construct() {
        $this->connection = new mysqli("127.0.0.1", "programma1", "12345", "centro_massaggi");
        if ($this->connection->connect_error) {
            die("Connessione al database fallita: " . $this->connection->connect_error);
        }
    }

    public function caricaDatiPrestazioni() {
        $query = "SELECT id, tipo, costo, id_massaggiatrice FROM prestazione";
        $result = $this->connection->query($query);
        return $result;
    }

    public function caricaDatiMassaggiatrici() {
        $query = "SELECT id, nome, eta FROM massaggiatrici";
        $result = $this->connection->query($query);
        return $result;
    }

    public function filtraPerCosto($costoFiltro) {
        $query = "SELECT id, tipo, costo, id_massaggiatrice FROM prestazione WHERE costo <= ?";
        $stmt = $this->connection->prepare($query);
        $stmt->bind_param("s", $costoFiltro);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result;
    }

    public function aggiungiMassaggiatrice($nome, $eta) {
        $stmt = $this->connection->prepare("INSERT INTO massaggiatrici (nome, eta) VALUES (?, ?)");
        $stmt->bind_param("si", $nome, $eta);
        $stmt->execute();
        $stmt->close();
    }

    public function aggiungiPrestazione($tipo, $costo, $id_massaggiatrice) {
        $stmt = $this->connection->prepare("INSERT INTO prestazione (tipo, costo, id_massaggiatrice) VALUES (?, ?, ?)");
        $stmt->bind_param("sii", $tipo, $costo, $id_massaggiatrice);
        $stmt->execute();
        $stmt->close();
    }

    public function eliminaMassaggiatrice($id) {
        $stmt = $this->connection->prepare("DELETE FROM massaggiatrici WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    public function eliminaPrestazione($id) {
        $stmt = $this->connection->prepare("DELETE FROM prestazione WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    public function modificaMassaggiatrice($id, $nome, $eta) {
        $stmt = $this->connection->prepare("UPDATE massaggiatrici SET nome = ?, eta = ? WHERE id = ?");
        $stmt->bind_param("sii", $nome, $eta, $id);
        $stmt->execute();
        $stmt->close();
    }

    public function modificaPrestazione($id, $tipo, $costo) {
        $stmt = $this->connection->prepare("UPDATE prestazione SET tipo = ?, costo = ? WHERE id = ?");
        $stmt->bind_param("sii", $tipo, $costo, $id);
        $stmt->execute();
        $stmt->close();
    }
}

$centroMassaggi = new CentroMassaggi();

// Operazioni in base all'azione del form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['azione'])) {
        $azione = $_POST['azione'];
        
        switch($azione) {
            case 'caricaDati':
                
                break;
            case 'filtraPerCosto':
                $costoFiltro = $_POST['costoFiltro'];
                $result = $centroMassaggi->filtraPerCosto($costoFiltro);
                break;
            case 'aggiungiMassaggiatrice':
                $nomeMassaggiatrice = $_POST['nomeMassaggiatrice'];
                $etaMassaggiatrice = $_POST['etaMassaggiatrice'];
                $centroMassaggi->aggiungiMassaggiatrice($nomeMassaggiatrice, $etaMassaggiatrice);
                break;
            case 'aggiungiPrestazione':
                $tipoPrestazione = $_POST['tipoPrestazione'];
                $costoPrestazione = $_POST['costoPrestazione'];
                $idMassaggiatrice = $_POST['idMassaggiatrice'];
                $centroMassaggi->aggiungiPrestazione($tipoPrestazione, $costoPrestazione, $idMassaggiatrice);
                break;
            case 'eliminaMassaggiatrice':
                $idMassaggiatrice = $_POST['idEliminaMassaggiatrice'];
                $centroMassaggi->eliminaMassaggiatrice($idMassaggiatrice);
                break;
            case 'eliminaPrestazione':
                $idPrestazione = $_POST['idEliminaPrestazione'];
                $centroMassaggi->eliminaPrestazione($idPrestazione);
                break;
            case 'modificaMassaggiatrice':
                $idMassaggiatrice = $_POST['idModificaMassaggiatrice'];
                $nomeMassaggiatrice = $_POST['nomeMassaggiatriceModifica'];
                $etaMassaggiatrice = $_POST['etaMassaggiatriceModifica'];
                $centroMassaggi->modificaMassaggiatrice($idMassaggiatrice, $nomeMassaggiatrice, $etaMassaggiatrice);
                break;
            case 'modificaPrestazione':
                $idPrestazione = $_POST['idModificaPrestazione'];
                $tipoPrestazione = $_POST['tipoPrestazioneModifica'];
                $costoPrestazione = $_POST['costoPrestazioneModifica'];
                $centroMassaggi->modificaPrestazione($idPrestazione, $tipoPrestazione, $costoPrestazione);
                break;
            default:
                
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Centro Massaggi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            margin-bottom: 20px;
        }
        input[type=text], input[type=number] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
        }
        input[type=submit] {
            background-color: #EE82EE;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #EE82EE;
        }
        select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>

<h1>Caricamento dei Dati</h1>

<!-- Carica Dati Prestazioni -->
<?php 
$resultPrestazioni = $centroMassaggi->caricaDatiPrestazioni();
if ($resultPrestazioni->num_rows > 0) {
    echo "<h2>Dati Prestazioni</h2>";
    echo "<table>";
    echo "<tr><th>ID</th><th>Tipo</th><th>Costo</th><th>ID Massaggiatrice</th></tr>";
    while ($row = $resultPrestazioni->fetch_assoc()) {
        echo "<tr><td>".$row["id"]."</td><td>".$row["tipo"]."</td><td>".$row["costo"]."</td><td>".$row["id_massaggiatrice"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nessun risultato trovato per le prestazioni.</p>";
}
?>

<!-- Carica Dati Massaggiatrici -->
<?php 
$resultMassaggiatrici = $centroMassaggi->caricaDatiMassaggiatrici();
if ($resultMassaggiatrici->num_rows > 0) {
    echo "<h2>Dati Massaggiatrici</h2>";
    echo "<table>";
    echo "<tr><th>ID</th><th>Nome</th><th>Età</th></tr>";
    while ($row = $resultMassaggiatrici->fetch_assoc()) {
        echo "<tr><td>".$row["id"]."</td><td>".$row["nome"]."</td><td>".$row["eta"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nessun risultato trovato per le massaggiatrici.</p>";
}
?>

<!-- Filtra per Costo -->
<h2>Filtra per Costo</h2>
<form method="post">
    Costo Massimo: <input type="number" name="costoFiltro" required><br>
    <input type="hidden" name="azione" value="filtraPerCosto">
    <input type="submit" value="Filtra">
</form>

<!-- Aggiungi Massaggiatrice -->
<h2>Aggiungi Massaggiatrice</h2>
<form method="post">
    Nome: <input type="text" name="nomeMassaggiatrice" required><br>
    Età: <input type="number" name="etaMassaggiatrice" required><br>
    <input type="hidden" name="azione" value="aggiungiMassaggiatrice">
    <input type="submit" value="Aggiungi">
</form>

<!-- Aggiungi Prestazione -->
<h2>Aggiungi Prestazione</h2>
<form method="post">
    Tipo: <input type="text" name="tipoPrestazione" required><br>
    Costo: <input type="number" name="costoPrestazione" required><br>
    ID Massaggiatrice: <input type="number" name="idMassaggiatrice" required><br>
    <input type="hidden" name="azione" value="aggiungiPrestazione">
    <input type="submit" value="Aggiungi">
</form>

<!-- Elimina Massaggiatrice -->
<h2>Elimina Massaggiatrice</h2>
<form method="post">
    ID Massaggiatrice: <input type="number" name="idEliminaMassaggiatrice" required><br>
    <input type="hidden" name="azione" value="eliminaMassaggiatrice">
    <input type="submit" value="Elimina">
</form>

<!-- Elimina Prestazione -->
<h2>Elimina Prestazione</h2>
<form method="post">
    ID Prestazione: <input type="number" name="idEliminaPrestazione" required><br>
    <input type="hidden" name="azione" value="eliminaPrestazione">
    <input type="submit" value="Elimina">
</form>

<!-- Modifica Massaggiatrice -->
<h2>Modifica Massaggiatrice</h2>
<form method="post">
    ID Massaggiatrice: <input type="number" name="idModificaMassaggiatrice" required><br>
    Nuovo Nome: <input type="text" name="nomeMassaggiatriceModifica" required><br>
    Nuova Età: <input type="number" name="etaMassaggiatriceModifica" required><br>
    <input type="hidden" name="azione" value="modificaMassaggiatrice">
    <input type="submit" value="Modifica">
</form>

<!-- Modifica Prestazione -->
<h2>Modifica Prestazione</h2>
<form method="post">
    ID Prestazione: <input type="number" name="idModificaPrestazione" required><br>
    Nuovo Tipo: <input type="text" name="tipoPrestazioneModifica" required><br>
    Nuovo Costo: <input type="number" name="costoPrestazioneModifica" required><br>
    <input type="hidden" name="azione" value="modificaPrestazione">
    <input type="submit" value="Modifica">
</form>

</body>
</html>